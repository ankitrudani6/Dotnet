﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ErrorLogDemo.Models
{
    public partial class ErrorLog
    {
        public int ErrorId { get; set; }
        public string ErrorMsg { get; set; }
        public string StackTrace { get; set; }
        public string Source { get; set; }
        public string Targetsite { get; set; }
    }
}
