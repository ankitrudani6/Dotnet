﻿using ErrorLogDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ErrorLogDemo
{
    public interface IErrorLog
    {
        string AddError(ErrorLog errorLog);
    }
    public class ErrorLogService : IErrorLog
    {
        public string AddError(ErrorLog errorLog)
        {
            using(TestErrorContext context = new TestErrorContext())
            {
                context.ErrorLogs.Add(errorLog);
                context.SaveChanges();
                return $"Error Stored";
            }
        }
    }
}
