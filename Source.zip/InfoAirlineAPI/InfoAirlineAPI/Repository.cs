﻿using InfoAirlineAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace InfoAirlineAPI
{
    public interface IRepository<TEntity> where TEntity : class
    {
        List<TEntity> GetAll();
        List<TEntity> Find(Expression<Func<TEntity, bool>> expression);
        TEntity GetByID(int id);
        TEntity Post(TEntity entity);
        TEntity Delete(TEntity entity);
        TEntity Update(TEntity entity, TEntity newEntity);
    }
    public class Repository<T> : IRepository<T> where T : class
    {
        private InfoAirlineContext DbContext { get; set; }
        public Repository(InfoAirlineContext airlineContext)
        {
            DbContext = airlineContext;
        }
        

        public List<T> GetAll()
        {
            return DbContext.Set<T>().ToList();
        }

        public T GetByID(int id)
        {
            return DbContext.Set<T>().Find(id);
        }

        public T Post(T entity)
        {
            DbContext.Add(entity);
            DbContext.SaveChanges();
            return entity;
        }

        public T Update(T entity, T newEntity)
        {
            DbContext.Entry(entity).CurrentValues.SetValues(newEntity);
            DbContext.SaveChanges();
            return newEntity;
        }

        public T Delete(T entity)
        {
            DbContext.Remove(entity);
            return entity;
        }

        public List<T> Find(Expression<Func<T, bool>> expression)
        {
            return DbContext.Set<T>().Where(expression).ToList();
        }
    }
}
