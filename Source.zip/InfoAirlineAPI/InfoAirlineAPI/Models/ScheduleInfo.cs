﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InfoAirlineAPI.Models
{
    [Keyless]
    public class ScheduleInfo
    {
        public string FlightName { get; set; }

        public DateTime DepartureDate { get; set; }

        public int Duration { get; set; }

        public string SourceName { get; set; }

        public string DestinationName { get; set; }
    }
}
