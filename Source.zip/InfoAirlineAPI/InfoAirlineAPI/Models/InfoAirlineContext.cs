﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace InfoAirlineAPI.Models
{
    public partial class InfoAirlineContext : DbContext
    {
        public InfoAirlineContext()
        {
        }

        public InfoAirlineContext(DbContextOptions<InfoAirlineContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Flight> Flights { get; set; }
        public virtual DbSet<Location> Locations { get; set; }
        public virtual DbSet<Passenger> Passengers { get; set; }
        public virtual DbSet<Schedule> Schedules { get; set; }
        public virtual DbSet<Travel> Travels { get; set; }
        public virtual DbSet<TicketDTO> TicketDTO { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
//                optionsBuilder.UseSqlServer("Data Source = PC0345\\MSSQL2019;Database=InfoAirline;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Flight>(entity =>
            {
                entity.ToTable("Flight");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Location>(entity =>
            {
                entity.ToTable("Location");

                entity.Property(e => e.LocationId).HasColumnName("LocationID");

                entity.Property(e => e.LocationName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Passenger>(entity =>
            {
                entity.ToTable("Passenger");

                entity.Property(e => e.PassengerId).HasColumnName("PassengerID");

                entity.Property(e => e.PassengerName)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.PhoneNumber).HasColumnType("numeric(10, 0)");
            });

            modelBuilder.Entity<Schedule>(entity =>
            {
                entity.ToTable("Schedule");

                entity.Property(e => e.ScheduleId).HasColumnName("ScheduleID");

                entity.Property(e => e.DepartureDateTime)
                    .HasColumnType("datetime")
                    .HasColumnName("DepartureDate_Time");

                entity.Property(e => e.FlightId).HasColumnName("FlightID");

                entity.Property(e => e.SourceId).HasColumnName("SourceID");

                entity.HasOne(d => d.DestinationNavigation)
                    .WithMany(p => p.ScheduleDestinationNavigations)
                    .HasForeignKey(d => d.Destination)
                    .HasConstraintName("FK_Schedule_Destination");

                entity.HasOne(d => d.Flight)
                    .WithMany(p => p.Schedules)
                    .HasForeignKey(d => d.FlightId)
                    .HasConstraintName("FK_Schedule_FlightID");

                entity.HasOne(d => d.Source)
                    .WithMany(p => p.ScheduleSources)
                    .HasForeignKey(d => d.SourceId)
                    .HasConstraintName("FK_Schedule_SourceID");
            });

            modelBuilder.Entity<Travel>(entity =>
            {
                entity.HasKey(e => e.Pnrno);

                entity.ToTable("Travel");

                entity.Property(e => e.Pnrno).HasColumnName("PNRNo");

                entity.Property(e => e.DateofBooking)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.PassengerId).HasColumnName("PassengerID");

                entity.Property(e => e.ScheduleId).HasColumnName("ScheduleID");

                entity.Property(e => e.Status)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.HasOne(d => d.Passenger)
                    .WithMany(p => p.Travels)
                    .HasForeignKey(d => d.PassengerId)
                    .HasConstraintName("FK_Travel_PassengerID");

                entity.HasOne(d => d.Schedule)
                    .WithMany(p => p.Travels)
                    .HasForeignKey(d => d.ScheduleId)
                    .HasConstraintName("FK_Travel_ScheduleID");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
