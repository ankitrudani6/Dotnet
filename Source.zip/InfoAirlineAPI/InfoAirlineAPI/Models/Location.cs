﻿using System;
using System.Collections.Generic;

#nullable disable

namespace InfoAirlineAPI.Models
{
    public partial class Location
    {
        public Location()
        {
            ScheduleDestinationNavigations = new HashSet<Schedule>();
            ScheduleSources = new HashSet<Schedule>();
        }

        public int LocationId { get; set; }
        public string LocationName { get; set; }

        public virtual ICollection<Schedule> ScheduleDestinationNavigations { get; set; }
        public virtual ICollection<Schedule> ScheduleSources { get; set; }
    }
}
