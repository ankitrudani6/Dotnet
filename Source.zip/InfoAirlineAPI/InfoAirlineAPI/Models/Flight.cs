﻿using System;
using System.Collections.Generic;

#nullable disable

namespace InfoAirlineAPI.Models
{
    public partial class Flight
    {
        public Flight()
        {
            Schedules = new HashSet<Schedule>();
        }

        public int Id { get; set; }
        public string Name { get; set; }

        public virtual ICollection<Schedule> Schedules { get; set; }
    }
}
