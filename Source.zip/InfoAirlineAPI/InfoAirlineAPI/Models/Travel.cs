﻿using System;
using System.Collections.Generic;

#nullable disable

namespace InfoAirlineAPI.Models
{
    public partial class Travel
    {
        public int Pnrno { get; set; }
        public int? ScheduleId { get; set; }
        public int? PassengerId { get; set; }
        public DateTime? DateofBooking { get; set; }
        public string Status { get; set; }

        public virtual Passenger Passenger { get; set; }
        public virtual Schedule Schedule { get; set; }
    }
}
