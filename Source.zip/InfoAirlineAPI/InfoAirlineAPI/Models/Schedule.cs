﻿using System;
using System.Collections.Generic;

#nullable disable

namespace InfoAirlineAPI.Models
{
    public partial class Schedule
    {
        public Schedule()
        {
            Travels = new HashSet<Travel>();
        }

        public int ScheduleId { get; set; }
        public int? FlightId { get; set; }
        public DateTime DepartureDateTime { get; set; }
        public int? Duration { get; set; }
        public int? SourceId { get; set; }
        public int? Destination { get; set; }

        public virtual Location DestinationNavigation { get; set; }
        public virtual Flight Flight { get; set; }
        public virtual Location Source { get; set; }
        public virtual ICollection<Travel> Travels { get; set; }
    }
}
