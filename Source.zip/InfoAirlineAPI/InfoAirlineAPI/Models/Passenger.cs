﻿using System;
using System.Collections.Generic;

#nullable disable

namespace InfoAirlineAPI.Models
{
    public partial class Passenger
    {
        public Passenger()
        {
            Travels = new HashSet<Travel>();
        }

        public int PassengerId { get; set; }
        public string PassengerName { get; set; }
        public decimal? PhoneNumber { get; set; }

        public virtual ICollection<Travel> Travels { get; set; }
    }
}
