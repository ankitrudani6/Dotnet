﻿using InfoAirlineAPI.Interfaces;
using InfoAirlineAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InfoAirlineAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LocationController : ControllerBase
    {
        private ILocation LocationService { get; set; }
        public LocationController(ILocation locationService)
        {
            LocationService = locationService;
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Ok(LocationService.GetAll());
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            return Ok(LocationService.GetByID(id));
        }

        [HttpGet("search/{name}")]
        public IActionResult Search(string name)
        {
            return Ok(LocationService.Find(t => t.LocationName == name));
        }

        [HttpPost]
        public IActionResult Post(Location location)
        {
            return Ok(LocationService.Post(location));
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, Location newLocation)
        {
            var location = LocationService.GetByID(id);
            return Ok(LocationService.Update(location, newLocation));
        }
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var location = LocationService.GetByID(id);
            return Ok(LocationService.Delete(location));
        }
    }
}
