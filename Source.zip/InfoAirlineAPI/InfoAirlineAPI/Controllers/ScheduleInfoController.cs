﻿using InfoAirlineAPI.Interfaces;
using InfoAirlineAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InfoAirlineAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ScheduleInfoController : ControllerBase
    {
        private IScheduleInfo ScheduleInfoService { get; set; }
        public ScheduleInfoController(IScheduleInfo scheduleInfoService)
        {
            ScheduleInfoService = scheduleInfoService;
        }

        [HttpPost]
        public IActionResult Post(ScheduleInfo scheduleInfo)
        {
            return Ok(ScheduleInfoService.AddSchedule(scheduleInfo));
        }
    }
}
