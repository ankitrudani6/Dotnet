﻿using InfoAirlineAPI.Interfaces;
using InfoAirlineAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InfoAirlineAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PassengerController : ControllerBase
    {
        private IPassenger PassengerService { get; set; }
        public PassengerController(IPassenger passengerService)
        {
            PassengerService = passengerService;
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Ok(PassengerService.GetAll());
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            return Ok(PassengerService.GetByID(id));
        }

        [HttpGet("search/{name}")]
        public IActionResult Search(string name)
        {
            return Ok(PassengerService.Find(t => t.PassengerName == name));
        }

        [HttpPost]
        public IActionResult Post(Passenger passenger)
        {
            return Ok(PassengerService.Post(passenger));
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, Passenger newPassenger)
        {
            var passenger = PassengerService.GetByID(id);
            return Ok(PassengerService.Update(passenger, newPassenger));
        }
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var passenger = PassengerService.GetByID(id);
            return Ok(PassengerService.Delete(passenger));
        }

        [HttpGet]
        [Route("GetTicket/{pnrno}")]
        public IActionResult GetTicket(int pnrno)
        {
            var jObject = JObject.Parse(PassengerService.GetTicketsDetails(pnrno).Result);
            return Ok(jObject);
        }
    }
}
