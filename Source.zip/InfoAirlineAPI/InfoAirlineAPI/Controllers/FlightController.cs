﻿using InfoAirlineAPI.Interfaces;
using InfoAirlineAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InfoAirlineAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FlightController : ControllerBase
    {
        private IFlight FlightService { get; set; }
        public FlightController(IFlight flightService)
        {
            FlightService = flightService;
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Ok(FlightService.GetAll());
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            return Ok(FlightService.GetByID(id));
        }

        [HttpGet("search/{fname}")]
        public IActionResult Search(string fname)
        {
            return Ok(FlightService.Find(t=>t.Name==fname));
        }
        [HttpPost]
        public IActionResult Post(Flight flight)
        {
            return Ok(FlightService.Post(flight));
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, Flight newFlight)
        {
            var flight = FlightService.GetByID(id);
            return Ok(FlightService.Update(flight, newFlight));
        }
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var flight = FlightService.GetByID(id);
            return Ok(FlightService.Delete(flight));
        }
    }
}
