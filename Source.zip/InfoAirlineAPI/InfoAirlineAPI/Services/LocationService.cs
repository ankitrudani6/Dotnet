﻿using InfoAirlineAPI.Interfaces;
using InfoAirlineAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InfoAirlineAPI.Services
{
    public class LocationService:Repository<Location>,ILocation
    {
        public LocationService(InfoAirlineContext airlineContext):base(airlineContext)
        {

        }
    }
}
