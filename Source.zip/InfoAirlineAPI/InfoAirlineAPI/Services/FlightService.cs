﻿using InfoAirlineAPI.Interfaces;
using InfoAirlineAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InfoAirlineAPI.Services
{
    public class FlightService:Repository<Flight>,IFlight
    {
        public FlightService(InfoAirlineContext airlineContext):base(airlineContext)
        {

        }
    }
}
