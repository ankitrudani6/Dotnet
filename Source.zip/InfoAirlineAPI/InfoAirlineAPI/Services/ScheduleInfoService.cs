﻿using InfoAirlineAPI.Interfaces;
using InfoAirlineAPI.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InfoAirlineAPI.Services
{
    public class ScheduleInfoService: IScheduleInfo
    {
        private InfoAirlineContext InfoAirlineContext { get; set; }
        public ScheduleInfoService(InfoAirlineContext airlineContext)
        {
            InfoAirlineContext = airlineContext;
        }

        public string AddSchedule(ScheduleInfo scheduleInfo)
        {
            
            var flight = InfoAirlineContext.Flights.Where(i => i.Name == scheduleInfo.FlightName).FirstOrDefault();
            var source = InfoAirlineContext.Locations.Where(i => i.LocationName == scheduleInfo.SourceName).FirstOrDefault();
            var destination = InfoAirlineContext.Locations.Where(i => i.LocationName == scheduleInfo.DestinationName).FirstOrDefault();

            Schedule schedule = new Schedule() { FlightId = flight.Id, DepartureDateTime = scheduleInfo.DepartureDate, Duration = scheduleInfo.Duration, SourceId = source.LocationId, Destination = destination.LocationId };

            InfoAirlineContext.Schedules.Add(schedule);
            InfoAirlineContext.SaveChanges();
            return $"Schedule Info Added";
        }
    }
}
