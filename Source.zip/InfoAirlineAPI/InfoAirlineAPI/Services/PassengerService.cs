﻿using InfoAirlineAPI.Interfaces;
using InfoAirlineAPI.Models;
using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace InfoAirlineAPI.Services
{
    public class PassengerService:Repository<Passenger>,IPassenger
    {
        private InfoAirlineContext InfoAirlineContext { get; set; } 
        public PassengerService(InfoAirlineContext airlineContext):base(airlineContext)
        {
            InfoAirlineContext = airlineContext;
        }

        public TicketDTO GetTicketsDetails(int PNRNo)
        {
            TicketDTO ticket = InfoAirlineContext.TicketDTO.FromSqlRaw("EXEC sp_TicketDetails {0}", PNRNo).AsEnumerable<TicketDTO>().FirstOrDefault();

            return ticket;
        }
    }
}
