﻿using InfoAirlineAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InfoAirlineAPI.Interfaces
{
    public interface IScheduleInfo
    {
        string AddSchedule(ScheduleInfo scheduleInfo);
    }
}
