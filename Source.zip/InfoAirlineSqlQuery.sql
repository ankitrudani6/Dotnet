CREATE DATABASE InfoAirline
GO

USE InfoAirline
GO

CREATE TABLE Flight(
	ID INT CONSTRAINT PK_Flight PRIMARY KEY IDENTITY(1,1),
	Name VARCHAR(20) NOT NULL
);
INSERT INTO Flight VALUES
('Indigo'),
('Airway'),
('Tata')

CREATE TABLE Location(
	LocationID INT CONSTRAINT PK_Location PRIMARY KEY IDENTITY(1,1),
	LocationName VARCHAR(20) NOT NULL
);

INSERT INTO Location VALUES
('Ahmedabad'),
('Delhi'),
('Mumbai'),
('Chennai'),
('Panjab')


--Schedule->ScheduleID, FlightID, DepartureDate_Time,Duration
-- SourceID(Ref location from location table),Destination(Ref locationid from location table)
CREATE TABLE Schedule(
	ScheduleID INT CONSTRAINT PK_Schedule PRIMARY KEY IDENTITY(1,1),
	FlightID INT CONSTRAINT FK_Schedule_FlightID FOREIGN KEY REFERENCES Flight,
	DepartureDate_Time DATETIME NOT NULL,
	Duration INT,--IN MINUTES
	SourceID INT CONSTRAINT FK_Schedule_SourceID FOREIGN KEY REFERENCES Location(LocationID),
	Destination INT CONSTRAINT FK_Schedule_Destination FOREIGN KEY REFERENCES Location(LocationID)
);

INSERT INTO Schedule VALUES
(1,'2022-08-05 10:15:00',120,1,2),
(2,'2022-08-06 05:00:00',80,2,3),
(3,'2022-08-06 02:30:00',150,1,3)


--Passenger->PassengerID,Name,PhoneNumber
CREATE TABLE Passenger(
	PassengerID INT CONSTRAINT PK_Passenger PRIMARY KEY IDENTITY(1,1),
	PassengerName VARCHAR(30),
	PhoneNumber NUMERIC(10) CONSTRAINT CK_PhoneNumber CHECK(PhoneNumber BETWEEN 6000000000 AND 9999999999)
);
INSERT INTO Passenger VALUES
('Ankit Rudani',9974289426),
('Dhairya Patel',9737440449),
('Kaushal Vadera',7567251133),
('Milan Patel',9979480828),
('Mihan Borad',8587412523)


-- Travel->PNRNo,ScheduleID(FK of schedule table),PassengerID(FK of Passenger Table),DateofBooking,Status
CREATE TABLE Travel(
	PNRNo INT CONSTRAINT PK_Travel PRIMARY KEY IDENTITY(10001,1),
	ScheduleID INT CONSTRAINT FK_Travel_ScheduleID FOREIGN KEY REFERENCES Schedule,
	PassengerID INT CONSTRAINT FK_Travel_PassengerID FOREIGN KEY REFERENCES Passenger,
	DateofBooking DATETIME DEFAULT GETDATE(),
	Status VARCHAR(15) CONSTRAINT CK_Travel_Status CHECK(Status IN ('Pending','Success','Failed','Cancelled'))
);
INSERT INTO Travel VALUES
(1,1,DEFAULT,'Success'),
(1,2,DEFAULT,'Pending'),
(2,3,DEFAULT,'Success'),
(2,4,DEFAULT,'Success'),
(3,5,DEFAULT,'Success')

-- Flight Name, Passenger Name, Departure Date (with Time), Arrival Date (with Time), SourceName, DestinationName, DateofBooking, Status
GO
CREATE PROCEDURE sp_TicketDetails @pnrno INT
AS
BEGIN
	SELECT 1 AS ID, ISNULL((SELECT t.PNRNo, F.Name, P.PassengerName, S.DepartureDate_Time, LS.LocationName AS SourceName, LD.LocationName AS DestinationName, T.DateofBooking, T.Status
	FROM Schedule S JOIN Flight F
		ON S.FlightID = F.ID
	JOIN Location LS
		ON S.SourceID = LS.LocationID
	JOIN Location LD
		ON S.Destination = LD.LocationID
	JOIN Travel T
		ON S.ScheduleID = T.ScheduleID
	JOIN Passenger P
		ON P.PassengerID = T.PassengerID
	--WHERE T.PNRNo = @pnrno
	FOR JSON PATH,WITHOUT_ARRAY_WRAPPER),'{}') AS Result
END

EXEC sp_TicketDetails 10001