# Angular Authentication Functionality with ASP.NET Core Identity
## https://code-maze.com/angular-authentication-aspnet-identity
This repo contains the source code for the "Angular Authentication Functionality with ASP.NET Core Identity" article on "Code Maze"
