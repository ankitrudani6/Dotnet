export interface UserForAuthenticationDto {
    email: string;
    password: string;
}