export interface RegistrationResponseDto {
    isSuccessfulRegistration: boolean;
    errros: string[];
}