export interface Company {
    id: string;
    name: string;
    fullAddress: string;
}