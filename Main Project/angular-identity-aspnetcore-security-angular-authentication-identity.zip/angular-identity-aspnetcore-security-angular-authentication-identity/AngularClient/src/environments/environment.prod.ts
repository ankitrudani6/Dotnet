export const environment = {
  production: true,
  urlAddress: 'http://www.companyemployees_client.com'
};
